#version 100

precision mediump float;

uniform sampler2D screenTexture;
uniform vec2 screenSize;
uniform float time;

uniform vec4 iColor; // %1, 1, 1, 1%
uniform float iOpacity; // %1%

void main()
{
    vec2 uv = gl_FragCoord.xy / screenSize;
    vec4 color = texture2D(screenTexture, uv);
    gl_FragColor = mix(color, iColor, iOpacity);
}