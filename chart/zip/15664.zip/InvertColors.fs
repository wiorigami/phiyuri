#version 100

precision mediump float;

uniform sampler2D screenTexture;
uniform vec2 screenSize;
uniform float time;

void main()
{
    vec2 uv = gl_FragCoord.xy / screenSize;
    vec4 color = texture2D(screenTexture, uv);
    color.rgb = vec3(1.0) - color.rgb;
    gl_FragColor = color;
}