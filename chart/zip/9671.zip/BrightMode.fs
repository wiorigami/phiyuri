#version 100
precision mediump float;

uniform sampler2D screenTexture;
varying lowp vec2 uv;

uniform float factor ;

mat4 rotate = mat4(
0.5748, -0.4252, -0.4252, 0.0,
-1.4252, -0.4252, -1.4252, 0.0,
-0.1444, -0.1444, 0.8556, 0.0,
1.25, 1.25, 1.25, 1.0
);

void main()
{
    vec4 pixel_color = texture2D(screenTexture, uv);
    gl_FragColor = mix(pixel_color, rotate * pixel_color, factor);
}