#version 100

precision mediump float;

varying vec2 uv; // 材质 UV
uniform vec2 screenSize; // 屏幕大小（注意是整个屏幕，并不只是谱面部分）
uniform sampler2D screenTexture; // 屏幕材质（同样也是整个屏幕的材质）
uniform float time; // 谱面时间，以秒为单位

uniform float amplitude; // 波纹幅度
uniform float frequency; // 波纹频率

#define PI 3.1415926

void main()
{
    float offset = sin(time * 50. + uv.y * frequency * PI) * amplitude;
    gl_FragColor = texture2D(screenTexture, uv + vec2(offset, 0));
}