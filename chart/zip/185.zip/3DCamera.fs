#version 100

precision mediump float;

varying vec2 uv; // 材质 UV
uniform vec2 screenSize; // 屏幕大小
uniform sampler2D screenTexture; // 屏幕材质
uniform bool perspective; // 投射方式（透视/正交）
uniform float near; // 近裁平面
uniform float far; // 远裁平面
uniform float posX; // 相机位置 x
uniform float posY; // 相机位置 y
uniform float posZ; // 相机位置 z

mat4 inverse(mat4 m)
{
    float Coef00 = m[2][2] * m[3][3] - m[3][2] * m[2][3];
    float Coef02 = m[1][2] * m[3][3] - m[3][2] * m[1][3];
    float Coef03 = m[1][2] * m[2][3] - m[2][2] * m[1][3];
    
    float Coef04 = m[2][1] * m[3][3] - m[3][1] * m[2][3];
    float Coef06 = m[1][1] * m[3][3] - m[3][1] * m[1][3];
    float Coef07 = m[1][1] * m[2][3] - m[2][1] * m[1][3];
    
    float Coef08 = m[2][1] * m[3][2] - m[3][1] * m[2][2];
    float Coef10 = m[1][1] * m[3][2] - m[3][1] * m[1][2];
    float Coef11 = m[1][1] * m[2][2] - m[2][1] * m[1][2];
    
    float Coef12 = m[2][0] * m[3][3] - m[3][0] * m[2][3];
    float Coef14 = m[1][0] * m[3][3] - m[3][0] * m[1][3];
    float Coef15 = m[1][0] * m[2][3] - m[2][0] * m[1][3];
    
    float Coef16 = m[2][0] * m[3][2] - m[3][0] * m[2][2];
    float Coef18 = m[1][0] * m[3][2] - m[3][0] * m[1][2];
    float Coef19 = m[1][0] * m[2][2] - m[2][0] * m[1][2];
    
    float Coef20 = m[2][0] * m[3][1] - m[3][0] * m[2][1];
    float Coef22 = m[1][0] * m[3][1] - m[3][0] * m[1][1];
    float Coef23 = m[1][0] * m[2][1] - m[2][0] * m[1][1];
    
    const vec4 SignA = vec4( 1.0, -1.0,  1.0, -1.0);
    const vec4 SignB = vec4(-1.0,  1.0, -1.0,  1.0);
    
    vec4 Fac0 = vec4(Coef00, Coef00, Coef02, Coef03);
    vec4 Fac1 = vec4(Coef04, Coef04, Coef06, Coef07);
    vec4 Fac2 = vec4(Coef08, Coef08, Coef10, Coef11);
    vec4 Fac3 = vec4(Coef12, Coef12, Coef14, Coef15);
    vec4 Fac4 = vec4(Coef16, Coef16, Coef18, Coef19);
    vec4 Fac5 = vec4(Coef20, Coef20, Coef22, Coef23);
    
    vec4 Vec0 = vec4(m[1][0], m[0][0], m[0][0], m[0][0]);
    vec4 Vec1 = vec4(m[1][1], m[0][1], m[0][1], m[0][1]);
    vec4 Vec2 = vec4(m[1][2], m[0][2], m[0][2], m[0][2]);
    vec4 Vec3 = vec4(m[1][3], m[0][3], m[0][3], m[0][3]);
    
    vec4 Inv0 = SignA * (Vec1 * Fac0 - Vec2 * Fac1 + Vec3 * Fac2);
    vec4 Inv1 = SignB * (Vec0 * Fac0 - Vec2 * Fac3 + Vec3 * Fac4);
    vec4 Inv2 = SignA * (Vec0 * Fac1 - Vec1 * Fac3 + Vec3 * Fac5);
    vec4 Inv3 = SignB * (Vec0 * Fac2 - Vec1 * Fac4 + Vec2 * Fac5);
    
    mat4 Inverse = mat4(Inv0, Inv1, Inv2, Inv3);
    
    vec4 Row0 = vec4(Inverse[0][0], Inverse[1][0], Inverse[2][0], Inverse[3][0]);
    
    float Determinant = dot(m[0], Row0);
    
    Inverse /= Determinant;
    
    return Inverse;
}

// unproject函数用于将屏幕坐标转换为世界坐标
vec4 unproject(vec3 screenCoords, mat4 cameraTransform, vec2 screenSize, bool perspective) {
  // 将屏幕坐标转换为视口坐标（-1.0到1.0之间）
  vec4 viewCoords = vec4((screenCoords.xy / screenSize) * 2.0 - 1.0, screenCoords.z, 1.0);

  // 如果使用透视投射，则需要进行透视除法
  if (perspective) {
    viewCoords.xyz /= viewCoords.w;
  }

  // 将视口坐标转换为世界坐标
  mat4 inverseCameraTransform = inverse(cameraTransform);
  return inverse(inverseCameraTransform) * viewCoords;
}

void main() {
  // 将材质UV转换为屏幕坐标
  vec2 screenCoords = uv * screenSize;

  // 计算深度值
  float depth = texture2D(screenTexture, uv).r;

  float width = screenSize.x, height = screenSize.y;

  mat4 projectionMatrix;

  if (perspective) // 透视
    projectionMatrix = mat4(
      vec4(2.0 / width, 0.0, 0.0, 0.0),
      vec4(0.0, 2.0 / height, 0.0, 0.0),
      vec4(0.0, 0.0, -2.0 / (far - near), 0.0),
      vec4(-1.0, -1.0, -(far + near) / (far - near), 1.0)
    );
  else
    projectionMatrix = mat4(
      vec4(2.0 * near / width, 0.0, 0.0, 0.0),
      vec4(0.0, 2.0 * near / height, 0.0, 0.0),
      vec4(0.0, 0.0, -(far + near) / (far - near), -1.0),
      vec4(0.0, 0.0, -2.0 * far * near / (far - near), 0.0)
    );

  vec3 position = vec3(posX, posY, posZ); // 相机的位置
  vec3 forward = normalize(vec3(0, 0, 0) - position); // 相机的正前方向
  vec3 right = normalize(cross(vec3(0, 1, 0), forward)); // 相机的右方向
  vec3 up = cross(forward, right); // 相机的上方向

  mat4 translateMatrix = mat4(
    vec4(1, 0, 0, 0),
    vec4(0, 1, 0, 0),
    vec4(0, 0, 1, 0),
    vec4(position.x, position.y, position.z, 1)
  );

  mat4 viewMatrix = mat4(
    vec4(right.x, right.y, right.z, 0),
    vec4(up.x, up.y, up.z, 0),
    vec4(-forward.x, -forward.y, -forward.z, 0),
    vec4(0, 0, 0, 1)
  );

  mat4 viewportMatrix = mat4(
    vec4(width / 2., 0., 0., 0.),
    vec4(0., height / 2., 0., 0.),
    vec4(0., 0., 1., 0.),
    vec4(0. + width / 2., 1. + height / 2., 0., 1.)
  );

  mat4 cameraTransform = projectionMatrix * translateMatrix * viewMatrix * viewportMatrix;

  // 将屏幕坐标转换为世界坐标
  vec4 worldCoords = unproject(vec3(screenCoords, depth), cameraTransform, screenSize, perspective);

  // 将世界坐标转换为相机坐标
  vec4 cameraCoords = cameraTransform * worldCoords;

  // 输出结果
  gl_FragColor = vec4(cameraCoords.xyz, 1.0);
}