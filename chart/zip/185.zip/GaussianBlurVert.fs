#version 100

precision mediump float;

varying vec2 uv; // 材质 UV
uniform vec2 screenSize; // 屏幕大小（注意是整个屏幕，并不只是谱面部分）
uniform sampler2D screenTexture; // 屏幕材质（同样也是整个屏幕的材质）
uniform float time; // 谱面时间，以秒为单位

uniform float radius; // 采样范围，越大性能开销越大
uniform float sigma; // 高斯函数参数，越大越模糊，不建议设为小于 0.1 的数

const float PI = 3.1415926;

float gaussionFunc(float x, float y)
{
    return 1. / (2. * PI * pow(sigma, 2.)) * exp(-(pow(x, 2.) + pow(y, 2.)) / (2. * pow(sigma, 2.)));
}

void main()
{
    int iRadius = int(radius);

    float sum = 0.;

    for (int i = -iRadius; i <= iRadius; ++ i)
    {
        vec2 point = uv + vec2(0., float(i)) / screenSize;

        if (point.x >= 0. && point.x <= 1. && point.y >= 0. && point.y <= 1.)
            sum += gaussionFunc(0., abs(float(i)));
    }

    vec4 color = vec4(0.);

    for (int i = -iRadius; i <= iRadius; ++ i)
    {
        vec2 point = uv + vec2(0., float(i)) / screenSize;

        if (point.x >= 0. && point.x <= 1. && point.y >= 0. && point.y <= 1.)
            color += texture2D(screenTexture, point) * gaussionFunc(0., abs(float(i))) / sum;
    }

    gl_FragColor = color;
}