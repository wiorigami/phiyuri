#version 100

precision mediump float;

varying vec2 uv; // 材质 UV
uniform vec2 screenSize; // 屏幕大小（注意是整个屏幕，并不只是谱面部分）
uniform sampler2D screenTexture; // 屏幕材质（同样也是整个屏幕的材质）
uniform float time; // 谱面时间，以秒为单位

uniform float intensity; // 发光强度
uniform float power; // 绽放强度
uniform float threshold; // 阈值
uniform vec4 color; //绽放颜色
uniform float blurSize; //采样半径

void main()
{
    vec4 sum = vec4(0);
    vec4 colorGlow = vec4(0);

    sum += texture(screenTexture, vec2(uv.x - 4.0*blurSize, uv.y)) * 0.05;
    sum += texture(screenTexture, vec2(uv.x - 3.0*blurSize, uv.y)) * 0.09;
    sum += texture(screenTexture, vec2(uv.x - 2.0*blurSize, uv.y)) * 0.12;
    sum += texture(screenTexture, vec2(uv.x - blurSize, uv.y)) * 0.15;
    sum += texture(screenTexture, vec2(uv.x, texcoord.y)) * 0.16;
    sum += texture(screenTexture, vec2(uv.x + blurSize, uv.y)) * 0.15;
    sum += texture(screenTexture, vec2(uv.x + 2.0*blurSize, uv.y)) * 0.12;
    sum += texture(screenTexture, vec2(uv.x + 3.0*blurSize, uv.y)) * 0.09;
    sum += texture(screenTexture, vec2(uv.x + 4.0*blurSize, uv.y)) * 0.05;

    sum += texture(screenTexture, vec2(uv.x, uv.y - 4.0*blurSize)) * 0.05;
    sum += texture(screenTexture, vec2(uv.x, uv.y - 3.0*blurSize)) * 0.09;
    sum += texture(screenTexture, vec2(uv.x, uv.y - 2.0*blurSize)) * 0.12;
    sum += texture(screenTexture, vec2(uv.x, uv.y - blurSize)) * 0.15;
    sum += texture(screenTexture, vec2(uv.x, uv.y)) * 0.16;
    sum += texture(screenTexture, vec2(uv.x, uv.y + blurSize)) * 0.15;
    sum += texture(screenTexture, vec2(uv.x, uv.y + 2.0*blurSize)) * 0.12;
    sum += texture(screenTexture, vec2(uv.x, uv.y + 3.0*blurSize)) * 0.09;
    sum += texture(screenTexture, vec2(uv.x, uv.y + 4.0*blurSize)) * 0.05;

    colorGlow = sum * intensity + texture(screenTexture, uv);
    float gray = colorGlow.r * 0.299 + colorGlow.g * 0.587 + colorGlow.b * 0.114;

    if (gray > threshold)
    {
        gl_FragColor = mix(colorGlow, color, power);
    }
    else
    {
        gl_FragColor = colorGlow;
    }
}