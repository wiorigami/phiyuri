#version 100

precision mediump float;

varying vec2 uv; // 材质 UV
uniform vec2 screenSize; // 屏幕大小（注意是整个屏幕，并不只是谱面部分）
uniform sampler2D screenTexture; // 屏幕材质（同样也是整个屏幕的材质）
uniform float time; // 谱面时间，以秒为单位

uniform float offsetX; // 画面整体偏移量X，两个维度范围均为 [0, 1]
uniform float offsetY; // 画面整体偏移量Y
uniform float alpha; // 偏移图案透明度，范围 [0, 1]

void main()
{
    vec4 colorOffset = texture2D(screenTexture, uv - vec2(offsetX, offsetY));
    vec4 colorNow = texture2D(screenTexture, uv);
    gl_FragColor = mix(colorNow, colorOffset, alpha);
}