#version 100

precision mediump float;

uniform sampler2D screenTexture;
uniform vec2 screenSize;
uniform float time;

float random(vec2 uv)
{
    return fract(sin(dot(uv.xy, vec2(12.9898, 78.233))) * 43758.5453123);
}

float noise(vec2 uv)
{
    vec2 i = floor(uv);
    vec2 f = fract(uv);
    f = f * f * (3.0 - 2.0 * f);
    
    float lb = random(i + vec2(0.0, 0.0));
    float rb = random(i + vec2(1.0, 0.0));
    float lt = random(i + vec2(0.0, 1.0));
    float rt = random(i + vec2(1.0, 1.0));
    
    return mix(mix(lb, rb, f.x), mix(lt, rt, f.x), f.y);
}

float Circle(vec2 uv, vec2 p, float r, float blur)
{
    float d = length(uv - p);
    float c = smoothstep(r + blur, r - blur, d);
    
    return c;
}

#define OCTAVES 8
float fbm(vec2 uv)
{
    float value = 0.0;
    float amplitude = 0.5;
    
    for (int i = 0; i < OCTAVES; ++ i)
    {
        value += noise(uv) * amplitude;
        
        amplitude *= 0.5;
        
        uv *= 2.0;
    }
    
    return value;
}

float rain(vec2 uv)
{
    float travelTime = (time * 0.2) + 0.1;
	
    vec2 tiling = vec2(1.0, 0.01);
    vec2 offset = vec2(travelTime * 0.5 + uv.x * 0.2, travelTime * 0.2);
	
    vec2 st = uv * tiling + offset;
    
    float rain = 0.1;  
    float f = noise(st * 200.5) * noise(st * 125.5);  
   	f = clamp(pow(abs(f), 15.0) * 1.5 * (rain * rain * 125.0), 0.0, 0.25);
    return f;
}

mat2 rotateMat(float angle)
{
    float rad = radians(angle);
    return mat2(cos(rad), -sin(rad), sin(rad), cos(rad));
}

void main()
{
    vec2 fragCoord = gl_FragCoord.xy;
    vec2 uv = fragCoord / screenSize.xy;
    vec4 originalColor = texture2D(screenTexture, uv) * 0.9;
    uv.x *= screenSize.x / screenSize.y;

    vec2 offset = uv - vec2(0.5);
    offset *= rotateMat(30.0); // 旋转30°
    uv = offset + vec2(0.5); // coord是旋转后坐标
   
    float cloud = (1.0 - (fbm((uv + 0.2) * uv.y + 0.1 * time))) * uv.y;
    cloud = clamp(0.9, 1.0, cloud);
    
   
    float moon = 0.0;
  	float rain = rain(uv);
    
    vec3 col = vec3(0.84, 0.925, 0.941) * moon * (1.0 - cloud * 1.2);
    col = mix(col, vec3(0.8, 0.8, 1.0), cloud * 0.0);
    col += vec3(1.0) * rain;
    
    gl_FragColor = vec4(col, 1.0) + originalColor;
}