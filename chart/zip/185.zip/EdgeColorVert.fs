#version 100
precision mediump float;

varying lowp vec2 uv;
uniform sampler2D screenTexture;

uniform float height; // 染色尽头与屏幕的距离，范围为 [0, 1]
uniform vec4 color; // 目标颜色，范围为 [0, 255]
uniform float maxAlpha; // 边缘最大透明度，范围为 [0, 1]

void main()
{
    vec4 clr = texture2D(screenTexture, uv);

    if (uv.x <= 0.5)
    {
        float ratio = 1.0 - min(1.0, uv.x / height);
        clr = mix(clr, color, ratio * maxAlpha);
    }
    else
    {
        float ratio = 1.0 - min(1.0, (1.0 - uv.x) / height);
        clr = mix(clr, color, ratio * maxAlpha);
    }

    gl_FragColor = clr;
}