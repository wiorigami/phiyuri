#version 100
precision mediump float;

uniform sampler2D screenTexture;
uniform vec2 screenSize;
uniform float time;
uniform vec4 color ;

void main()
{
    vec2 uv = gl_FragCoord.xy / screenSize;
    vec4 Hue = texture2D(screenTexture, uv);
    Hue = color * Hue;
    gl_FragColor = Hue;
}