#version 100
precision mediump float;

varying lowp vec2 uv;
uniform sampler2D screenTexture;

vec4 screenTextureColor;
uniform float brightness; // %1.0%

void main()
{
    screenTextureColor = texture2D(screenTexture, uv);
    gl_FragColor = vec4((screenTextureColor.rgb * vec3(brightness * brightness)), screenTextureColor.w);
}
