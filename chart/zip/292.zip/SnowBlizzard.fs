#version 100

precision mediump float;

uniform sampler2D screenTexture;
uniform vec2 screenSize;
uniform float time;

uniform float iSizeRate; // %0.3%
uniform float iXSpeed; // %8.0%
uniform float iYSpeed; // %0.8%
uniform float iLayers; // %15.0%

#define HASHSCALE1 .1031
#define HASHSCALE3 vec3(.1031, .1030, .0973)
#define HASHSCALE4 vec3(.1031, .1030, .0973, .1099)

float Hash11(float p)
{
	vec3 p3 = fract(vec3(p) * HASHSCALE1);
    p3 += dot(p3, p3.yzx + 19.19);
    return fract((p3.x + p3.y) * p3.z); 
}

vec2 Hash22(vec2 p)
{
	vec3 p3 = fract(vec3(p.xyx) * HASHSCALE3);
    p3 += dot(p3, p3.yzx + 19.19);
    return fract((p3.xx + p3.yz) * p3.zy);
}

vec2 Rand22(vec2 co)
{
    float x = fract(sin(dot(co.xy, vec2(122.9898, 783.233))) * 43758.5453);
    float y = fract(sin(dot(co.xy, vec2(457.6537, 537.2793))) * 37573.5913);
    return vec2(x,y);
}

vec3 SnowSingleLayer(vec2 uv, float layer)
{
    vec3 acc = vec3(0.0, 0.0, 0.0);
    uv = uv * (2.0 + layer);
    float xOffset = uv.y * (((Hash11(layer) * 2.0 - 1.0) * 0.5 + 1.0) * iXSpeed);
    float yOffset = (iYSpeed * time);
    uv += vec2(xOffset, yOffset);
    vec2 rgrid = Hash22(floor(uv) + (31.1759 * layer));
    uv = fract(uv);
    uv -= (rgrid * 2.0 - 1.0) * 0.35;
    uv -= 0.5;
    float r = length(uv);
    //让大小变化点
    float circleSize = 0.05 * (1.0 + 0.3 * sin(time * iSizeRate));
    float val = smoothstep(circleSize, -circleSize, r);
    vec3 col = vec3(val, val, val) * rgrid.x;
    return col;
}

void main()
{
    vec2 fragCoord = gl_FragCoord.xy;

    // Normalized pixel coordinates (from 0 to 1)
    vec2 uv = fragCoord / screenSize.xy;

    uv *= vec2(screenSize.x / screenSize.y, 1.0);
    
    vec3 acc = vec3(0, 0, 0);
    for (float i = 0.0; i < iLayers; ++ i)
        acc += SnowSingleLayer(uv, i);

    // Output to screen
    gl_FragColor = vec4(acc, 1.0) + texture2D(screenTexture, fragCoord.xy / screenSize.xy);
}