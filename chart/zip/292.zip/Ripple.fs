#version 100

precision highp float;

uniform sampler2D screenTexture;
uniform vec2 screenSize;
uniform float time;

uniform float speed; // %10.0%
uniform float freq; // %20.0%
uniform float amp; // %0.006%

void main()
{
    vec2 fragCoord = gl_FragCoord.xy;
    
	vec2 uv = fragCoord.xy / screenSize.xy;
    
    vec2 ripple = vec2(cos((length(uv-0.5)*freq)+(-time*speed)),sin((length(uv-0.5)*freq)+(-time*speed)))*amp;
    //Version (Stronger at center, weaker at outside):
    //ripple = vec2(cos((length(uv-0.5)*freq)+(-time*speed)),sin((length(uv-0.5)*freq)+(-time*speed)))*(clamp(1.-(length(uv-0.5)*1.5),0.,1.)*amp);
	
    //TIP: If you don't want them to go around in circles but make them go foward and backwards at 45 degrees, just change cos to sin.
    
    gl_FragColor = texture2D(screenTexture,uv+ripple);
}