#version 100

precision mediump float;

uniform vec2 screenSize;
uniform sampler2D screenTexture;
uniform vec2 time;
uniform vec2 uv;

uniform float iScale; // %60.0%
uniform vec4 iStarColor; // %1.0, 0.3, 1.0, 1.0%
uniform float iRotate; // %30.0%
uniform float iCenterX; // %0.5%
uniform float iCenterY;// %0.5%
uniform float iStarLuminosity; // %1e3%
uniform float iAlpha; // %0.5%

const float PI = 3.1415926;

void main()
{
    vec2 iCenter = vec2(iCenterX, iCenterY);
    vec2 center = iCenter * screenSize.xy / screenSize.y;
    vec4 originalColor = texture2D(screenTexture, gl_FragCoord.xy / screenSize.xy);

    // coordinate rotate
    float iRad = iRotate / 180.0 * PI;
    mat2 rotateMat = mat2(cos(-iRad), -sin(-iRad), sin(-iRad), cos(-iRad));
    vec2 fragCoord = gl_FragCoord.xy - center * screenSize.y;
    fragCoord.xy = fragCoord.xy * rotateMat;
    
    // star center
    vec2 pos = (fragCoord.xy + center * screenSize.y) / screenSize.y;
	float d = length(pos - center) * iScale;
	vec3 color, spectrum = iStarColor.rgb * iStarLuminosity;
	color = spectrum / (3.0 * d * d * d);
    float alpha = clamp(color.r / iStarColor.r, 0.0, 1.0);
    
    // star light
	d = length((pos - center) * (vec2(10.0, 0.5))) * iScale;
	color += spectrum / (d * d * d);
	d = length((pos - center) * (vec2(0.5, 10.0))) * iScale;
	color += spectrum / (d * d * d);
    alpha = clamp(color.r / iStarColor.r, 0.0, 1.0);
    
    // mix color
    vec4 col;
    col = mix(originalColor, vec4(color, 1.0), alpha * iAlpha);
        
    gl_FragColor = col;
}