#version 100

precision mediump float;

uniform sampler2D screenTexture;
uniform vec2 screenSize;
uniform float time;

uniform vec2 iCenter; // %0.5, 0.5%
uniform float iDuration; // %4.0%
uniform float iEffectIntensity; // %0.07%
uniform float iStartTime;

const float PI = 3.14159265359;

float easeInOut(float t)
{
	return (t * t) * (3.0 - 2.0 * t);
}

vec2 resolution()
{
	return screenSize.xy;
}

float aspectRatio()
{
	return resolution().x / resolution().y;
}

float sinc(float x)
{
	return sin(x) / x;
}

// -6 to 6 give visible diffs - more than that
float sigmoid(float x)
{
	return 1.0 / (1.0 + exp(-x));
}

float lerp(float a, float b, float t)
{
	return a + (b - a) * t;
}

#define EFFECT_RANGE_PARAM 0.15

/**
* p: the point for which to compute the offset
* center: the center of the ripple
* age: the time of the effect
**/
vec2 rippleOffset(vec2 p, vec2 center, float age)
{
	vec2 offset = (center - p) * vec2(aspectRatio(), 1.0);

	float centerOffset = length(offset);

	float distanceFactor = 1.0 - sigmoid(-4.0 + 6.0 * (centerOffset - EFFECT_RANGE_PARAM));

	float slope = sinc(12.0 * (easeInOut(age) - centerOffset * 0.7)  * PI * 2.0) * distanceFactor;

	return normalize(offset) * slope * iEffectIntensity;
}


void main()
{
    vec2 fragCoord = gl_FragCoord.xy;
	vec2 uv = fragCoord.xy / screenSize.xy;
    
    float t = fract((time - iStartTime) / iDuration);
    
    vec2 offset = rippleOffset(uv, iCenter, t);

	gl_FragColor = vec4(texture2D(screenTexture, uv + offset));
    //fragColor.x = offset.x * 100.0 + 0.5;
    //fragColor.y = 0.0;
    //fragColor.z = offset.y * 100.0 + 0.5;
}