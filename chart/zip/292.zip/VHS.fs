#version 100

precision mediump float;

uniform sampler2D screenTexture;
uniform vec2 screenSize;
uniform float time;

uniform float iIntensity; // %1.0%

const float range = 0.05;
const float noiseQuality = 250.0;

float noiseIntensity;
float offsetIntensity;
float colorOffsetIntensity;

float rand(vec2 co)
{
    return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);
}

float verticalBar(float pos, float uvY, float offset)
{
    float edge0 = (pos - range);
    float edge1 = (pos + range);

    float x = smoothstep(edge0, pos, uvY) * offset;
    x -= smoothstep(pos, edge1, uvY) * offset;
    return x;
}

void main()
{
    noiseIntensity = iIntensity * 0.01;
    offsetIntensity = iIntensity * 0.02;
    colorOffsetIntensity = iIntensity * 0.5;
	vec2 uv = gl_FragCoord.xy / screenSize;
    
    for (float i = 0.0; i < 0.71; i += 0.1313)
    {
        float d = mod(time * i, 1.7);
        float o = sin(1.0 - tan(time * 0.24 * i));
    	o *= offsetIntensity;
        uv.x += verticalBar(d, uv.y, o);
    }
    
    float uvY = uv.y;
    uvY *= noiseQuality;
    uvY = float(int(uvY)) * (1.0 / noiseQuality);
    float noise = rand(vec2(time * 0.00001, uvY));
    uv.x += noise * noiseIntensity;

    vec2 offsetR = vec2(0.006 * sin(time), 0.0) * colorOffsetIntensity;
    vec2 offsetG = vec2(0.0073 * (cos(time * 0.97)), 0.0) * colorOffsetIntensity;
    
    float r = texture2D(screenTexture, uv + offsetR).r;
    float g = texture2D(screenTexture, uv + offsetG).g;
    float b = texture2D(screenTexture, uv).b;

    vec4 tex = vec4(r, g, b, 1.0);
    gl_FragColor = tex;
}