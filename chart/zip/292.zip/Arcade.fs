#version 100

precision mediump float;

uniform sampler2D screenTexture;
uniform vec2 screenSize;
uniform float time;

const float EV = 1.0;
const float expand = 1.02;
const float stripeIntensity = 1000.0;

void main()
{
    vec2 uv = gl_FragCoord.xy / screenSize;
    // expand the view
    float d2 = dot(uv - vec2(0.5), uv - vec2(0.5));
    vec2 coord = (uv - vec2(0.5)) * (expand + d2 * (1.0 - expand)) + vec2(0.5);
    vec3 color = texture2D(screenTexture, coord).rgb;
    // bloom
    vec3 bloom = color * vec3(0.902, 1.0, 0.8784);
    color -= bloom;
    color += bloom * pow(2.0, EV);
    // stripe
    vec2 sc = vec2((sin(coord.y * stripeIntensity) + 1.0) / 2.0, (cos(coord.y * stripeIntensity) + 1.0) / 2.0);
    color += color * sc.xyx;
    // fade out edge
    float dist = min(min(uv.x, 1.0 - uv.x), min(uv.y, 1.0 - uv.y));
    
    if (dist <= 0.04)
    {
        float alpha = 400.0 * pow(dist - 0.04, 2.0);
        color = mix(color, vec3(0.0), alpha);
    }

    gl_FragColor = vec4(color, 1.0);
}