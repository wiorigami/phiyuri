#version 100

precision mediump float;

uniform sampler2D screenTexture;
uniform vec2 screenSize;
uniform float time;

const float expand = 0.97;
const float noiseIntensity = 0.2;
const float stripeIntensity = 1000.0;
const float sepiaIntensity = 0.5;
const mat3 sepia = mat3(
    0.393, 0.349, 0.272,
    0.769, 0.686, 0.534,
    0.189, 0.168, 0.131);

float simpleNoise(vec2 uv)
{
    return fract(sin(dot(uv, vec2(12.9898, 78.233))) * 43758.5453);
}

void main()
{
    vec2 uv = gl_FragCoord.xy / screenSize;
    // expand the view
    float d2 = dot(uv - vec2(0.5), uv - vec2(0.5));
    vec2 coord = (uv - vec2(0.5)) * (expand + d2 * (1.0 - expand)) + vec2(0.5);
    vec4 color = texture2D(screenTexture, coord);
    // noise
    float n = simpleNoise(coord * time);
    vec3 result = mix(color.rgb, vec3(n), noiseIntensity);
    // stripe
    vec2 sc = vec2((sin(coord.y * stripeIntensity) + 1.0) / 2.0, (cos(coord.y * stripeIntensity) + 1.0) / 2.0);
    result += color.rgb * sc.xyx;
    // sepia
    mat3 sepiaDiff = mat3(1.0) + sepiaIntensity * (sepia - mat3(1.0));
    result = sepiaDiff * result;
    // big stripe
    float down = -time * 0.5;
    float up = -time * 0.5 + 0.15;
    down = mod(down, 1.0);
    up = mod(up, 1.0);

    if (up >= down && coord.y == clamp(coord.y, down, up))
        result = mix(result, vec3(0.0), 0.2);
    
    if (up < down && (coord.y <= up || coord.y >= down))
        result = mix(result, vec3(0.0), 0.2);
    
    gl_FragColor = vec4(result, 1.0);
}