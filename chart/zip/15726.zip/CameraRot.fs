#version 100

precision mediump float;

uniform sampler2D screenTexture;
uniform vec2 screenSize;
uniform float time;

uniform float iAngle; // %0.0%
uniform vec4 iOutsideColor; // %0.0, 0.0, 0.0, 1.0%

mat2 rot(float angle)
{
    angle = radians(angle);
    return mat2(cos(angle), -sin(angle), sin(angle), cos(angle));
}

void main()
{
    vec2 uv = gl_FragCoord.xy / screenSize;

    uv -= vec2(0.5);
    uv = uv * screenSize * rot(iAngle) / screenSize;
    uv += vec2(0.5);

    if (uv != clamp(uv, vec2(0.0), vec2(1.0)))
        gl_FragColor = iOutsideColor;
    else
        gl_FragColor = texture2D(screenTexture, uv);
}